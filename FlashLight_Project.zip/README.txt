Flash Light - مشروع Android صغير جدًا

الفكرة:
زر واحد لتشغيل فلاش الهاتف وإيقافه.

البناء:
المشروع مجهز للعمل مع GitHub Actions، لذلك لا تحتاج Android Studio أو Android SDK على هاتفك.
ارفع المجلد إلى مستودع GitHub، ثم افتح Actions وشغّل "Build APK".
بعد انتهاء البناء ستجد ملف FlashLight-APK في Artifacts.

ملاحظة:
التطبيق يستخدم صلاحية CAMERA لأنها مطلوبة للتحكم في فلاش الكاميرا.
