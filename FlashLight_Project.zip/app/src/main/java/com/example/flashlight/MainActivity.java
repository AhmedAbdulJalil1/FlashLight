package com.example.flashlight;

import android.app.Activity;
import android.os.Bundle;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
    private CameraManager cameraManager;
    private String cameraId;
    private boolean isOn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        cameraManager = (CameraManager) getSystemService(CAMERA_SERVICE);
        try {
            cameraId = cameraManager.getCameraIdList()[0];
        } catch (CameraAccessException | ArrayIndexOutOfBoundsException e) {
            Toast.makeText(this, "الفلاش غير متاح", Toast.LENGTH_LONG).show();
        }

        Button button = new Button(this);
        button.setText("تشغيل الفلاش");
        button.setTextSize(24);

        button.setOnClickListener(v -> {
            if (cameraId == null) return;
            try {
                isOn = !isOn;
                cameraManager.setTorchMode(cameraId, isOn);
                button.setText(isOn ? "إيقاف الفلاش" : "تشغيل الفلاش");
            } catch (CameraAccessException e) {
                Toast.makeText(this, "تعذر التحكم في الفلاش", Toast.LENGTH_SHORT).show();
            }
        });

        LinearLayout layout = new LinearLayout(this);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(40, 40, 40, 40);
        layout.addView(button, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        setContentView(layout);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isOn && cameraManager != null && cameraId != null) {
            try {
                cameraManager.setTorchMode(cameraId, false);
            } catch (CameraAccessException ignored) {}
            isOn = false;
        }
    }
}
